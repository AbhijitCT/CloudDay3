﻿using System.ComponentModel.DataAnnotations;

namespace HMS_WebApi.DTO
{
    public record BookAptDTO
    {
        public string? PatientId { get; set; }
        public string? NurseId { get; set; }
        public DateOnly ApptDt { get; set; }
    }

}


