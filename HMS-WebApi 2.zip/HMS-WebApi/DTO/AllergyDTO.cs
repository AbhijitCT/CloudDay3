﻿namespace HMS_WebApi.DTO
{
    public record AllergyDTO
    {
        public string AllergyId { get; set; }

        public string? AllergyNm { get; set; }
    }
}
