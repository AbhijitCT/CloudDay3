﻿namespace HMS_WebApi.DTO
{
    public record DiagonsisDTO
    {
        public string DiagId { get; set; }

        public string? DiagDesc { get; set; }
    }
}
