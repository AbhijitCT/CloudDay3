﻿namespace HMS_WebApi.DTO
{
    public record BloodPressureDTO
    {
        public string BpId { get; set; }

        public string? BpType { get; set; }

    }
}
