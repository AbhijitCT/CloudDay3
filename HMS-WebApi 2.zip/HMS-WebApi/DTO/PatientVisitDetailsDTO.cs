﻿namespace HMS_WebApi.DTO
{
    public class PatientVisitDetailsDTO
    {
        public string? ApptId { get; set; }

        public string? VisitId { get; set; }

        public DateTime? NxtVisitDt { get; set; }

        public double? Hight { get; set; }

        public double? Weight { get; set; }

        public string? BpType { get; set; }

        public string? DiagName { get; set; }

        public string? MedicName { get; set; }

        public string? AllergyName { get; set; }
    }
}
