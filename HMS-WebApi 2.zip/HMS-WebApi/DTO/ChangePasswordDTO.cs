﻿using System.ComponentModel.DataAnnotations;
namespace HMS_WebApi.DTO
{
    public record ChangePasswordDTO
    {
        [Required]
        public string? Username { get; set; }

        [Required]
        public string? OldPassword { get; set; }

        [Required]
        [RegularExpression("^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])[a-zA-Z0-9]{5,15}$", ErrorMessage = "Password must conatins atleast one uppercase, one lowercase one numeric character.")]
        public string? NewPassword { get; set; }
    }
}
