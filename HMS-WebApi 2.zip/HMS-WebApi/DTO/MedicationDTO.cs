﻿namespace HMS_WebApi.DTO
{
    public record MedicationDTO
    {
        public string MedicId { get; set; }

        public string? MedicNm { get; set; }
    }
}
