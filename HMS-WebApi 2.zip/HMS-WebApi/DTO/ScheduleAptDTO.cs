﻿using System.ComponentModel.DataAnnotations;

namespace HMS_WebApi.DTO
{
    public record ScheduleAptDTO
    {
        public string? ApptId { get; set; }
        public string? PhyId { get; set; }
    }
}
