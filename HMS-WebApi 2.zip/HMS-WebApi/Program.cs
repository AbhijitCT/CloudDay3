
using HMS_WebApi.Models;
using HMS_WebApi.Services;
using HMS_WebApi.Services.AdminModule;
using HMS_WebApi.Services.AppointmentModule;
using HMS_WebApi.Services.InboxModule;
using HMS_WebApi.Services.LoginModule;
using HMS_WebApi.Services.PatientModule;
using HMS_WebApi.Services.PatientVisitModule;
using Microsoft.EntityFrameworkCore;

namespace HMS_WebApi
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.

            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();
            builder.Services.AddScoped<IAdmin, AdminOperations>();
            builder.Services.AddScoped<IAppointment, AppointmentManager>();
            builder.Services.AddScoped<ILogin, LoginOperations>();
            builder.Services.AddScoped<IInbox, InboxModule>();
            builder.Services.AddScoped<IPatient, PatientOperation>();
            builder.Services.AddScoped<IPatientVisit, PatientVisitOperations>();
            builder.Services.AddDbContext<Group1DotNetContext>(opt =>
            {   
                opt.UseSqlServer(builder.Configuration["ConnectionStrings:AzureSQL"]);
            });


            var app = builder.Build();
            app.UseCors(builder => builder
           .AllowAnyOrigin()
           .AllowAnyMethod()
           .AllowAnyHeader());

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}
