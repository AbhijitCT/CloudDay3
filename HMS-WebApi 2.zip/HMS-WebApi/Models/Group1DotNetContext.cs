﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace HMS_WebApi.Models;

public partial class Group1DotNetContext : DbContext
{
    public Group1DotNetContext()
    {
    }

    public Group1DotNetContext(DbContextOptions<Group1DotNetContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Allergy> Allergies { get; set; }

    public virtual DbSet<Appoinment> Appoinments { get; set; }

    public virtual DbSet<BlockedUser> BlockedUsers { get; set; }

    public virtual DbSet<BloodPerssureType> BloodPerssureTypes { get; set; }

    public virtual DbSet<Diagnosis> Diagnoses { get; set; }

    public virtual DbSet<DiseaseCategory> DiseaseCategories { get; set; }

    public virtual DbSet<Master> Masters { get; set; }

    public virtual DbSet<Medication> Medications { get; set; }

    public virtual DbSet<PatientVisit> PatientVisits { get; set; }

    public virtual DbSet<Role> Roles { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("server=CTAAD2KVVP73\\SQLEXPRESS;database=Group_1_DotNet;uid=sa;password=password_123;TrustServerCertificate=true");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Allergy>(entity =>
        {
            entity.HasKey(e => e.AllergyId).HasName("PK__Allergie__5855FEB771D61008");

            entity.Property(e => e.AllergyId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Allergy_Id");
            entity.Property(e => e.AllergyNm)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("Allergy_Nm");
            entity.Property(e => e.DisezCatId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Disez_Cat_Id");

            entity.HasOne(d => d.DisezCat).WithMany(p => p.Allergies)
                .HasForeignKey(d => d.DisezCatId)
                .HasConstraintName("FK__Allergies__Disez__47DBAE45");
        });

        modelBuilder.Entity<Appoinment>(entity =>
        {
            entity.HasKey(e => e.ApptId).HasName("PK__Appoinme__B9B1A517D5EE64C1");

            entity.Property(e => e.ApptId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Appt_Id");
            entity.Property(e => e.ApptDt).HasColumnName("Appt_Dt");
            entity.Property(e => e.IsCancelled).HasColumnName("Is_Cancelled");
            entity.Property(e => e.IsSkd).HasColumnName("Is_Skd");
            entity.Property(e => e.IsVistComp).HasColumnName("Is_Vist_Comp");
            entity.Property(e => e.NurseId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Nurse_Id");
            entity.Property(e => e.PatientId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Patient_Id");
            entity.Property(e => e.PhyId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Phy_Id");

            entity.HasOne(d => d.Nurse).WithMany(p => p.AppoinmentNurses)
                .HasForeignKey(d => d.NurseId)
                .HasConstraintName("FK__Appoinmen__Nurse__48CFD27E");

            entity.HasOne(d => d.Patient).WithMany(p => p.AppoinmentPatients)
                .HasForeignKey(d => d.PatientId)
                .HasConstraintName("FK__Appoinmen__Patie__49C3F6B7");

            entity.HasOne(d => d.Phy).WithMany(p => p.AppoinmentPhies)
                .HasForeignKey(d => d.PhyId)
                .HasConstraintName("FK__Appoinmen__Phy_I__4AB81AF0");
        });

        modelBuilder.Entity<BlockedUser>(entity =>
        {
            entity.HasKey(e => e.Username).HasName("PK__BlockedU__536C85E5FDAB3825");

            entity.Property(e => e.Username)
                .HasMaxLength(25)
                .IsUnicode(false);
            entity.Property(e => e.BlockedTime).HasColumnType("datetime");

            entity.HasOne(d => d.UsernameNavigation).WithOne(p => p.BlockedUser)
                .HasPrincipalKey<Master>(p => p.Username)
                .HasForeignKey<BlockedUser>(d => d.Username)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__BlockedUs__Usern__656C112C");
        });

        modelBuilder.Entity<BloodPerssureType>(entity =>
        {
            entity.HasKey(e => e.BpId).HasName("PK__BloodPer__E07A06F164D57243");

            entity.ToTable("BloodPerssureType");

            entity.Property(e => e.BpId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("BP_Id");
            entity.Property(e => e.BpType)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("BP_Type");
        });

        modelBuilder.Entity<Diagnosis>(entity =>
        {
            entity.HasKey(e => e.DiagId).HasName("PK__Diagnosi__1DA760EC2BEF86B6");

            entity.ToTable("Diagnosis");

            entity.Property(e => e.DiagId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Diag_Id");
            entity.Property(e => e.DiagDesc)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("Diag_Desc");
            entity.Property(e => e.DisezCatId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Disez_Cat_Id");

            entity.HasOne(d => d.DisezCat).WithMany(p => p.Diagnoses)
                .HasForeignKey(d => d.DisezCatId)
                .HasConstraintName("FK__Diagnosis__Disez__4BAC3F29");
        });

        modelBuilder.Entity<DiseaseCategory>(entity =>
        {
            entity.HasKey(e => e.DisezCatId).HasName("PK__DiseaseC__DEBA7EEBA45881CD");

            entity.ToTable("DiseaseCategory");

            entity.Property(e => e.DisezCatId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Disez_Cat_Id");
            entity.Property(e => e.DisezCatNm)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("Disez_Cat_Nm");
        });

        modelBuilder.Entity<Master>(entity =>
        {
            entity.HasKey(e => e.MstrId).HasName("PK__Master__07BEA408FF7C4B26");

            entity.ToTable("Master");

            entity.HasIndex(e => e.Username, "UQ__Master__536C85E48B9D9798").IsUnique();

            entity.Property(e => e.MstrId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Mstr_Id");
            entity.Property(e => e.DisezCatId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Disez_Cat_Id");
            entity.Property(e => e.Email).HasMaxLength(100);
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("Is_Active");
            entity.Property(e => e.Name)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Password).HasMaxLength(30);
            entity.Property(e => e.RoleId).HasColumnName("Role_Id");
            entity.Property(e => e.Username)
                .HasMaxLength(25)
                .IsUnicode(false);

            entity.HasOne(d => d.DisezCat).WithMany(p => p.Masters)
                .HasForeignKey(d => d.DisezCatId)
                .HasConstraintName("FK__Master__Disez_Ca__4D94879B");

            entity.HasOne(d => d.Role).WithMany(p => p.Masters)
                .HasForeignKey(d => d.RoleId)
                .HasConstraintName("FK__Master__Role_Id__4CA06362");
        });

        modelBuilder.Entity<Medication>(entity =>
        {
            entity.HasKey(e => e.MedicId).HasName("PK__Medicati__F75DD60D554A0E3C");

            entity.ToTable("Medication");

            entity.Property(e => e.MedicId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Medic_Id");
            entity.Property(e => e.DiagId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Diag_Id");
            entity.Property(e => e.MedicNm)
                .HasMaxLength(150)
                .IsUnicode(false)
                .HasColumnName("Medic_Nm");

            entity.HasOne(d => d.Diag).WithMany(p => p.Medications)
                .HasForeignKey(d => d.DiagId)
                .HasConstraintName("FK__Medicatio__Diag___4E88ABD4");
        });

        modelBuilder.Entity<PatientVisit>(entity =>
        {
            entity.HasKey(e => e.VisitId).HasName("PK__PatientV__DB5CD37078570EEA");

            entity.ToTable("PatientVisit");

            entity.HasIndex(e => e.ApptId, "UQ__PatientV__B9B1A51680226A18").IsUnique();

            entity.Property(e => e.VisitId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Visit_Id");
            entity.Property(e => e.AllergyId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Allergy_Id");
            entity.Property(e => e.ApptId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Appt_Id");
            entity.Property(e => e.BookedBy)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Booked_By");
            entity.Property(e => e.BpId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("BP_Id");
            entity.Property(e => e.DiagId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Diag_Id");
            entity.Property(e => e.MedicId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Medic_Id");
            entity.Property(e => e.NxtVisitDt)
                .HasColumnType("datetime")
                .HasColumnName("Nxt_Visit_Dt");
            entity.Property(e => e.PatientId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Patient_Id");
            entity.Property(e => e.PhyId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Phy_Id");

            entity.HasOne(d => d.Allergy).WithMany(p => p.PatientVisits)
                .HasForeignKey(d => d.AllergyId)
                .HasConstraintName("FK__PatientVi__Aller__5441852A");

            entity.HasOne(d => d.Appt).WithOne(p => p.PatientVisit)
                .HasForeignKey<PatientVisit>(d => d.ApptId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__PatientVi__Appt___4F7CD00D");

            entity.HasOne(d => d.BookedByNavigation).WithMany(p => p.PatientVisitBookedByNavigations)
                .HasForeignKey(d => d.BookedBy)
                .HasConstraintName("FK__PatientVi__Booke__6EF57B66");

            entity.HasOne(d => d.Bp).WithMany(p => p.PatientVisits)
                .HasForeignKey(d => d.BpId)
                .HasConstraintName("FK__PatientVi__BP_Id__5165187F");

            entity.HasOne(d => d.Diag).WithMany(p => p.PatientVisits)
                .HasForeignKey(d => d.DiagId)
                .HasConstraintName("FK__PatientVi__Diag___52593CB8");

            entity.HasOne(d => d.Medic).WithMany(p => p.PatientVisits)
                .HasForeignKey(d => d.MedicId)
                .HasConstraintName("FK__PatientVi__Medic__534D60F1");

            entity.HasOne(d => d.Patient).WithMany(p => p.PatientVisitPatients)
                .HasForeignKey(d => d.PatientId)
                .HasConstraintName("FK__PatientVi__Patie__5070F446");

            entity.HasOne(d => d.Phy).WithMany(p => p.PatientVisitPhies)
                .HasForeignKey(d => d.PhyId)
                .HasConstraintName("FK__PatientVi__Phy_I__6E01572D");
        });

        modelBuilder.Entity<Role>(entity =>
        {
            entity.HasKey(e => e.RoleId).HasName("PK__Roles__D80AB4BBD9E4B78E");

            entity.Property(e => e.RoleId)
                .ValueGeneratedNever()
                .HasColumnName("Role_Id");
            entity.Property(e => e.RoleNm)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("Role_Nm");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
