﻿using System;
using System.Collections.Generic;

namespace HMS_WebApi.Models;

public partial class Medication
{
    public string MedicId { get; set; } = null!;

    public string? MedicNm { get; set; }

    public string? DiagId { get; set; }

    public virtual Diagnosis? Diag { get; set; }

    public virtual ICollection<PatientVisit> PatientVisits { get; set; } = new List<PatientVisit>();
}
