﻿using System;
using System.Collections.Generic;

namespace HMS_WebApi.Models;

public partial class Appoinment
{
    public string ApptId { get; set; } = null!;

    public string? NurseId { get; set; }

    public string? PatientId { get; set; }

    public string? PhyId { get; set; }

    public bool? IsSkd { get; set; }

    public bool? IsVistComp { get; set; }

    public DateOnly ApptDt { get; set; }

    public bool? IsCancelled { get; set; }

    public virtual Master? Nurse { get; set; }

    public virtual Master? Patient { get; set; }

    public virtual PatientVisit? PatientVisit { get; set; }

    public virtual Master? Phy { get; set; }
}
