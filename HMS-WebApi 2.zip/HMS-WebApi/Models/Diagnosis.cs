﻿using System;
using System.Collections.Generic;

namespace HMS_WebApi.Models;

public partial class Diagnosis
{
    public string DiagId { get; set; } = null!;

    public string? DiagDesc { get; set; }

    public string? DisezCatId { get; set; }

    public virtual DiseaseCategory? DisezCat { get; set; }

    public virtual ICollection<Medication> Medications { get; set; } = new List<Medication>();

    public virtual ICollection<PatientVisit> PatientVisits { get; set; } = new List<PatientVisit>();
}
