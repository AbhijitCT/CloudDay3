﻿using System;
using System.Collections.Generic;

namespace HMS_WebApi.Models;

public partial class Allergy
{
    public string AllergyId { get; set; } = null!;

    public string? AllergyNm { get; set; }

    public string? DisezCatId { get; set; }

    public virtual DiseaseCategory? DisezCat { get; set; }

    public virtual ICollection<PatientVisit> PatientVisits { get; set; } = new List<PatientVisit>();
}
