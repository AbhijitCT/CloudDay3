﻿using HMS_WebApi.DTO;
using HMS_WebApi.Models;
using HMS_WebApi.Services.InboxModule;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.SqlServer.Server;
using System.Text;

namespace HMS_WebApi.Services.PatientModule
{
    public class PatientOperation : IPatient
    {
        public Group1DotNetContext context;
        public PatientOperation(Group1DotNetContext context)
        {
            this.context = context;
        }

        public async Task<IEnumerable<DiseaseCategory>> GetDisease()
        {
            return await context.DiseaseCategories.ToListAsync();
        }
        public async Task<string> ViewPersonalDetails(string? PatId)
        {
            var patient = context.Masters.Find(PatId);
            if (patient != null)
            {
                StringBuilder details = new StringBuilder();
                details.Append($"ID: {patient.MstrId}\n");
                details.Append($"Name: {patient.Name}\n");
                details.Append($"Username: {patient.Username}\n");
                details.Append($"DOB: {patient.Dob}\n");
                details.Append($"Email: {patient.Email}\n");
                details.Append($"Disease Category ID: {patient.DisezCatId}\n");
                return await Task.FromResult(details.ToString());
            }
            return null;
        }
        public async Task<(byte[],string)> DownloadPersonalDetails(string? PatId)
        {
            var patient = await context.Masters.FindAsync(PatId);
            if (patient == null) {
                return (null, null);
            }

            StringBuilder details = new StringBuilder();
            details.AppendLine("ID,Name,DOB,Email,Disease Category ID");
            details.AppendLine($"{patient.MstrId},{patient.Name},{patient.Dob},{patient.Email},{patient.DisezCatId}");
            string filename = $"{patient.Username}_Details.csv";
            //File.WriteAllText(filename, details.ToString());

            byte[] fileBytes = Encoding.UTF8.GetBytes(details.ToString());
            return (fileBytes,filename);

        }


        public async Task<IEnumerable<AppointmentDetailsDTO>> ViewVisitHistory(string PatID)
        {
            return await context.Appoinments.Where(a => a.PatientId == PatID && a.IsVistComp == true).Select(a => new AppointmentDetailsDTO
            {
                AppointmentID = a.ApptId,
                NurseName = a.Nurse.Name,
                AptDate = a.ApptDt,
                PhyName = a.Phy.Name
            }).ToListAsync();

        }

        //public async Task<IEnumerable<DiseaseCategory>> GetDisease()
        //{
        //    return await context.DiseaseCategories.ToListAsync();
        //}

        public bool CheckUserNameExist(string username)
        {

            return context.Masters.Any(x => EF.Functions.Collate(x.Username, "SQL_Latin1_General_CP1_CS_AS") == username && x.IsActive == true);
        }

        public void RegisterPatient(MasterDTO pat)
        {

            Master patient = new Master();
            
            patient.MstrId = "HMS-PAT" + (context?.Masters.Where(n => n.RoleId == 2).Count() + 1);
            
            patient.Name = pat.Name;
            patient.Username = pat.Username;
            patient.Password = pat.Password;
            patient.Email = pat.Email;
            patient.Dob = pat.Dob;
            patient.RoleId = pat.RoleId;
            patient.DisezCatId = pat.DisezCatId;
            context?.Add(patient);
            context?.SaveChanges();

        }
    }

}
