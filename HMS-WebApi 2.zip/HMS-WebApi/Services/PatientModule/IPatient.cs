﻿using HMS_WebApi.DTO;
using HMS_WebApi.Models;
using HMS_WebApi.Services.InboxModule;
using Microsoft.AspNetCore.Mvc;

namespace HMS_WebApi.Services.PatientModule
{
    public interface IPatient
    {
        public Task<string> ViewPersonalDetails(string? PatId);
        public Task<(byte[], string)> DownloadPersonalDetails(string? PatId);

        bool CheckUserNameExist(string username);
        public Task<IEnumerable<AppointmentDetailsDTO>> ViewVisitHistory(string? PatId);
        //Task<IEnumerable<DiseaseCategory>> GetDisease();
        //public void RaiseAppointment(Appoinment apt);
        //public void BookAppointment(Appoinment appt);

        void RegisterPatient(MasterDTO pat);
        public Task<IEnumerable<DiseaseCategory>> GetDisease();


    }
}
