﻿using HMS_WebApi.DTO;
using HMS_WebApi.Models;
using Microsoft.EntityFrameworkCore;

namespace HMS_WebApi.Services.AppointmentModule
{
    public class AppointmentManager : IAppointment
    {
        private Group1DotNetContext context;
        public AppointmentManager(Group1DotNetContext context)
        {
            this.context = context;
        }

        public async Task<IEnumerable<MasterDetails>> GetNursesForDscCtg(string DscCtgID)
        {
            var users = (from Master in context.Masters
                         where Master.IsActive == true && Master.RoleId == 3 && Master.DisezCatId == DscCtgID
                         select new MasterDetails
                         {
                             MasterId = Master.MstrId,
                             MasterName = Master.Name
                         });

            return users;
            //return await context.Masters.Where(m => m.IsActive == true && m.RoleId == 3 && m.DisezCatId == DscCtgID).ToListAsync();
        }
        public async Task<IEnumerable<MasterDetails>> GetPhysicianForDscCtg(string DscCtgID)
        {
            //var users = (from Master in context.Masters
            //            where Master.IsActive == true && Master.RoleId == 2 && Master.DisezCatId == DscCtgID
            //            select new MasterDetails
            //            {
            //                MasterId = Master.MstrId,
            //                MasterName = Master.Name
            //            });

            //return users;

            return await context.Masters.Where(m => m.IsActive == true && m.RoleId == 1 && m.DisezCatId == DscCtgID).Select(master => new MasterDetails { MasterId = master.MstrId, MasterName = master.Name }).ToListAsync();
            //context.Masters.Where(m => m.IsActive == true)
        }
        public async Task<IEnumerable<AppointmentDetailsDTO>> GetAllScheduledAppointmentHistoryForNurse(string NurseID)
        {
            return await context.Appoinments.Where(a => a.NurseId == NurseID && a.IsSkd == true).Select(a => new AppointmentDetailsDTO
            {
                AppointmentID = a.ApptId,
                PatientID = a.PatientId,
                PatientName = a.Patient.Name,
                AptDate = a.ApptDt,
                PhyName = a.Phy.Name
            }).ToListAsync();   
        }
        //public bool BookAppointment(Appoinment appt)
        //{
        //    context.Appoinments.Add(appt);
        //    return true;
        //}
        /// <summary>
        /// Books Appointment for provided patient
        /// </summary>
        /// <param name="patient">Patient for which appointment needs to be booked</param>
        /// <param name="NurseId">Nurse who books appointment</param>
        /// <param name="aptdate">Date for which appointment to be booked on</param>
        /// <param name="context">To save data to database</param>
        public void BookAppointment(/*Master patient,*/ BookAptDTO apt)
        {
            //try
            //{
                Appoinment appoinment = new Appoinment();
                appoinment.ApptId = "HMS-APT" + (this.context.Appoinments.Count() + 1);
                appoinment.Nurse = context.Masters.Find(apt.NurseId);
                appoinment.PatientId = apt.PatientId;
                appoinment.NurseId = apt.NurseId;
                appoinment.ApptDt = apt.ApptDt;
                appoinment.IsSkd = false;
                appoinment.IsVistComp = false;
                appoinment.Patient = context.Masters.Find(appoinment.PatientId);
                context.Masters.Find(appoinment.PatientId).AppoinmentPatients.Add(appoinment);
                context?.Add(appoinment);
                context?.SaveChanges();
            //}
            //catch (Exception)
            //{
            //    throw new BookAppointmentFailedException($"Failed to Book Appointment. Please try again...");
            //}
        }

        /// <summary>
        /// Schedules Appointments for Patient
        /// </summary>
        /// <param name="apt">Appointment ID generated at time of Booking Appointment</param>
        /// <param name="PhyID">Physicians ID to whom appointment needs to be Scheduled</param>
        /// <param name="context">To Persist data to Database</param>
        public void ScehduleAppointment(/*string? aptId, string? PhyID*/ScheduleAptDTO appoinment)
        {
            try
            {
                //Check if available
                var apt = context.Appoinments.Find(appoinment.ApptId);
                apt.PhyId = appoinment.PhyId;
                apt.IsSkd = true;
                apt.Phy = context.Masters.Find(appoinment.PhyId);
                context.SaveChanges();
            }
            catch (Exception)
            {
                throw new ScheduleAppointmentFailedException("Appointment is not scheduled.");
            }
        }
        public void CancelAppoitnment(string AptID)
        {
            Console.WriteLine("Hello"+AptID);
            context.Appoinments.Find(AptID).IsCancelled=true;
            context.SaveChanges() ; 
        }

        /// <summary>
        /// To get Number of Appointment booked by patient that needs to be Scheduled
        /// </summary>
        /// <param name="NurseID">The Nurse for whom appointment count needs to check</param>
        /// <returns>Return count of Appointment for provided nurses ID that needs to be Scheduled</returns>
        public int GetAppointmentCountForNurse(string NurseID)
        {

            var appoinments = from appointment in context.Appoinments
                              where appointment.NurseId == NurseID && appointment.IsSkd == false
                              select appointment;
            return appoinments.Count();

        }
        public  bool CheckAppointmentExistForNurse(string? AptID, string? NursID)
        {
            return context.Appoinments.Any(apt => apt.ApptId == AptID && apt.NurseId == NursID && apt.IsSkd != true && apt.IsVistComp!=true && apt.IsCancelled!=true);
        }
        public  bool CheckAppointmentExistForPhy(string? AptID, string? PhyID)
        {
            return context.Appoinments.Any(apt => apt.ApptId == AptID && apt.PhyId == PhyID && apt.IsSkd==true && apt.IsVistComp != true && apt.IsCancelled!=true);
        }
        //public static AppointmentDetails GetAppointmentDetails(string? AptID, Group1DotNetContext context)
        //{
        //    var aps = (from appointment in context.Appoinments
        //               where appointment.ApptId == AptID && appointment.IsSkd == true
        //               select new AppointmentDetails
        //               {
        //                   PatientID = appointment.PatientId,
        //                   PatientName = appointment.Patient.Name,
        //                   AppointmentID = appointment.ApptId,
        //                   AptDate = appointment.ApptDt,
        //                   NurseName = appointment.Nurse.Name,
        //                   PhyName = appointment.Phy.Name
        //               });
        //    return aps.SingleOrDefault();
        //}

    }

    public class BookAppointmentFailedException : Exception
    {
        public BookAppointmentFailedException(string message) : base(message)
        {
        }
    }

    public class ScheduleAppointmentFailedException : Exception
    {
        public ScheduleAppointmentFailedException(string message) : base(message) { }
    }

}
