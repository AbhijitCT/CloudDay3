﻿using HMS_WebApi.DTO;
using HMS_WebApi.Models;

namespace HMS_WebApi.Services.AppointmentModule
{
    public interface IAppointment
    {
        public Task<IEnumerable<MasterDetails>> GetPhysicianForDscCtg(string DscCtg);
        public Task<IEnumerable<MasterDetails>> GetNursesForDscCtg(string DscCtg);
        public Task<IEnumerable<AppointmentDetailsDTO>> GetAllScheduledAppointmentHistoryForNurse(string NurseID);

        public void BookAppointment(BookAptDTO appt);
        public void ScehduleAppointment(ScheduleAptDTO appt);

        public void CancelAppoitnment(string AptID);
    }
}
