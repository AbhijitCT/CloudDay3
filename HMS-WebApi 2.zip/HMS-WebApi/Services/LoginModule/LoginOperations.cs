﻿using HMS_WebApi.Models;
using Microsoft.EntityFrameworkCore;

namespace HMS_WebApi.Services.LoginModule
{
    public class LoginOperations : ILogin
    {
        private readonly Group1DotNetContext _context;

        public LoginOperations(Group1DotNetContext context)
        {
            _context = context;
        }


        public bool CheckUserNameExist(string username)
        {

            return _context.Masters.Any(x => EF.Functions.Collate(x.Username, "SQL_Latin1_General_CP1_CS_AS") == username && x.IsActive == true);
        }

        public bool CheckUserPassword(string username, string password)
        {
            return _context.Masters.Any(x => EF.Functions.Collate(x.Password, "SQL_Latin1_General_CP1_CS_AS") == password && EF.Functions.Collate(x.Username, "SQL_Latin1_General_CP1_CS_AS") == username && x.IsActive == true);
        }

        public bool BlockUser(string username)
        {
            BlockedUser? user = new BlockedUser
            {
                Username = username,
                BlockedTime = DateTime.Now

            };
            _context?.BlockedUsers.Add(user);
            _context?.SaveChanges();
            return true;
        }

        public bool CheckUserInBlockLst(string username)
        {
            BlockedUser? user = _context?.BlockedUsers.Find(username);

            if (user != null && DateTime.Now <= user.BlockedTime.AddMinutes(1))
            {
                return true;
            }
            else if (user != null && DateTime.Now >= user.BlockedTime.AddMinutes(1))
            {
                _context?.BlockedUsers.Remove(user);
                _context?.SaveChanges();
            }
            return false;
        }

        public Master? GetMaster(string username, string password)
        {
            return _context.Masters.Where(e => e.Username == username && e.Password == password).SingleOrDefault();
        }

        public void ForgetPasswordDetails(string username, out string name, out string password)
        {

            Master? master = _context.Masters.Where(x => x.Username == username).SingleOrDefault();
            name = master.Name;
            password = master.Password;
        }

        public bool UpdatePassword(string username, string password)
        {

            var master = _context.Masters.Where(e => e.Username == username).SingleOrDefault();
            if (master != null)
            {
                master.Password = password;
                _context.SaveChanges();
                return true;
            }
            return false;
        }
    }
}
