﻿using HMS_WebApi.Models;

namespace HMS_WebApi.Services.LoginModule
{
    public interface ILogin
    {
        bool CheckUserNameExist(string username);
        bool CheckUserPassword(string username, string password);
        bool BlockUser(string username);
        bool CheckUserInBlockLst(string username);
        Master? GetMaster(string username, string password);
        void ForgetPasswordDetails(string username, out string name, out string password);
        bool UpdatePassword(string username, string password);
    }
}
