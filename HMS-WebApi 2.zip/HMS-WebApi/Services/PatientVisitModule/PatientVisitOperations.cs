﻿using HMS_WebApi.DTO;
using HMS_WebApi.Models;
using Microsoft.EntityFrameworkCore;


namespace HMS_WebApi.Services.PatientVisitModule
{
    public class PatientVisitOperations : IPatientVisit
    {
        private readonly Group1DotNetContext _context;

        public PatientVisitOperations(Group1DotNetContext context)
        {
            _context = context;
        }

        public string CreatePatientVisit(PatientVisitDTO patVisit)
        {

            var appointment = _context.Appoinments.Find(patVisit.ApptId);
            var patientVisit = new PatientVisit
            {
                VisitId = "HMS-VIS" + (_context.PatientVisits.Count() + 1),
                ApptId = patVisit.ApptId,
                PhyId = appointment.PhyId,
                PatientId = appointment.PatientId,
                BookedBy = appointment.NurseId,
                NxtVisitDt =patVisit.NxtVisitDt,
                Hight = patVisit.Hight,
                Weight = patVisit.Weight,
                BpId = patVisit.BpId,
                DiagId = patVisit.DiagId,
                MedicId = patVisit.MedicId,
                AllergyId = patVisit.AllergyId,
                Appt = appointment,
                Patient = _context.Masters.Find(appointment.PatientId),
                BookedByNavigation = _context.Masters.Find(appointment.NurseId),
                Phy = _context.Masters.Find(appointment.PhyId),
                Allergy = _context.Allergies.Find(patVisit.AllergyId),
                Medic = _context.Medications.Find(patVisit.MedicId),
                Diag = _context.Diagnoses.Find(patVisit.DiagId),
                Bp = _context.BloodPerssureTypes.Find(patVisit.BpId)
            };

            appointment.IsVistComp = true;
            _context.PatientVisits.Add(patientVisit);
            _context.SaveChanges();


            return patientVisit.VisitId;
        }


        public Task<List<AppointmentDetailsDTO>> PatientVisitsForPhy(string PhyId)
        {
            return  _context.Appoinments.Where(a => a.PhyId == PhyId  && a.IsVistComp == true).Select(a => new AppointmentDetailsDTO
            {
                AppointmentID = a.ApptId,
                PatientID = a.PatientId,
                NurseName = a.Nurse.Name,
                AptDate = a.ApptDt,
                PatientName = a.Patient.Name
            }).ToListAsync();
        }

        public Task<PatientVisitDetailsDTO> PatientVisitDetails(string AptId)
        {
            var VisitDetails = _context.PatientVisits.Where(a => a.ApptId==AptId).SingleOrDefault();
            if (VisitDetails != null)
            {
                var visitDTO = new PatientVisitDetailsDTO();
                visitDTO.ApptId = VisitDetails.ApptId;
                visitDTO.VisitId = VisitDetails.VisitId;
                visitDTO.NxtVisitDt = VisitDetails.NxtVisitDt != null ? VisitDetails.NxtVisitDt : null;
                visitDTO.MedicName = _context.Medications.Find(VisitDetails.MedicId).MedicNm;
                visitDTO.DiagName = _context.Diagnoses.Find(VisitDetails.DiagId).DiagDesc;
                visitDTO.AllergyName = _context.Allergies.Find(VisitDetails.AllergyId) != null? _context.Allergies.Find(VisitDetails.AllergyId).AllergyNm : null ;
                visitDTO.BpType = _context.BloodPerssureTypes.Find(VisitDetails.BpId).BpType;
                visitDTO.Hight = VisitDetails.Hight;
                visitDTO.Weight = VisitDetails.Weight;
                return Task.FromResult(visitDTO);

            }
            return null; //Exception Handling
        }
        public Task<List<string>> GetAptIDsForPhy(string PhyId)
        {
            return _context.Appoinments.Where(ap => ap.PhyId == PhyId && ap.IsVistComp == false && ap.IsSkd == true).Select(ap => ap.ApptId).ToListAsync();
        }

        public Task<List<BloodPressureDTO>> GetBloodPressureType()
        {
            return _context.BloodPerssureTypes.Select(bp => new BloodPressureDTO { 
                BpId = bp.BpId,
                BpType = bp.BpType }).ToListAsync();
        }

        public Task<List<DiagonsisDTO>> GetDigForDszCtg(string DscCtgId)
        {
            return _context.Diagnoses.Where(dg => dg.DisezCatId == DscCtgId).Select(bp => new DiagonsisDTO
            {
               DiagDesc = bp.DiagDesc,
               DiagId   = bp.DiagId
            }).ToListAsync();
        }

        public Task<List<MedicationDTO>> GetMedForDigCtg(string DigCtgId)
        {
            return _context.Medications.Where(md => md.DiagId == DigCtgId).Select(m => new MedicationDTO { MedicId = m.MedicId, MedicNm = m.MedicNm }).ToListAsync();
        }
        public Task<List<AllergyDTO>> GetAlgTypForDigCtg(string DszCtgId)
        {
            return _context.Allergies.Where(al => al.DisezCatId== DszCtgId).Select(m => new AllergyDTO { AllergyId = m.AllergyId, AllergyNm = m.AllergyNm }).ToListAsync();
        }
    }
}
