﻿using HMS_WebApi.DTO;
using HMS_WebApi.Models;

namespace HMS_WebApi.Services.PatientVisitModule
{
    public interface IPatientVisit
    {
        string CreatePatientVisit(PatientVisitDTO patientVisit);

        Task<List<string>> GetAptIDsForPhy(string PhyId);

        Task<List<BloodPressureDTO>> GetBloodPressureType();

        Task<List<DiagonsisDTO>> GetDigForDszCtg(string DscCtgId);

        Task<List<MedicationDTO>> GetMedForDigCtg(string DigCtg);
        Task<List<AllergyDTO>> GetAlgTypForDigCtg(string DigCtg);

        //PatientVisit GetVisitDetails(string visitId);
        Task<List<AppointmentDetailsDTO>> PatientVisitsForPhy(string PhyId);
        public Task<PatientVisitDetailsDTO> PatientVisitDetails(string VisitID);

        
    }
}
