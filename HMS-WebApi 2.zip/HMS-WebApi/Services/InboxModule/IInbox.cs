﻿using HMS_WebApi.DTO;
using HMS_WebApi.Models;
using System;

namespace HMS_WebApi.Services.InboxModule
{
    public interface IInbox
    {
        public Task<IEnumerable<AppointmentDetailsDTO>> GetAppointmentToBeScheduledList(string? NurseID);
        public Task<IEnumerable<AppointmentDetailsDTO>> UpcomingGetScheduledAppointmentList(string? PhyID);

        public Task<IEnumerable<AppointmentDetailsDTO>> GetScheduledAppointmentListForToday(string? PhyID);
    }
}
