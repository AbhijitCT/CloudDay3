﻿using HMS_WebApi.DTO;
using HMS_WebApi.Models;
using Microsoft.EntityFrameworkCore;
using System;

namespace HMS_WebApi.Services.InboxModule
{
    
    public class InboxModule : IInbox
	{
		private Group1DotNetContext context;
		public InboxModule(Group1DotNetContext context)
		{
			this.context = context;
		}

		public async Task<IEnumerable<AppointmentDetailsDTO>> GetAppointmentToBeScheduledList(string? NurseID)
		{
            return await context.Appoinments.Where(a => a.NurseId == NurseID && a.IsSkd == false).Select (a=> new AppointmentDetailsDTO {
                    AppointmentID = a.ApptId,
                    PatientID= a.PatientId,
                    PatientName = a.Patient.Name,
                    AptDate = a.ApptDt
                }).ToListAsync();
		}

        public async Task<IEnumerable<AppointmentDetailsDTO>> UpcomingGetScheduledAppointmentList(string? PhyID)
		{
			return await context.Appoinments.Where(a=> a.PhyId == PhyID && a.IsSkd ==true && 
                                                   a.IsVistComp == false && a.IsCancelled !=true &&
                                                   a.ApptDt > DateOnly.FromDateTime(DateTime.Now)).Select(a=> new AppointmentDetailsDTO {
                    AppointmentID = a.ApptId,
                    PatientID = a.PatientId,
                    PatientName = a.Patient.Name,
                    NurseName = a.Nurse.Name,
                    AptDate = a.ApptDt
                }).ToListAsync(); 
		}

        public async Task<IEnumerable<AppointmentDetailsDTO>> GetScheduledAppointmentListForToday(string? PhyID)
        {
            return await context.Appoinments.Where(a => a.PhyId == PhyID && a.IsSkd == true &&
                                                   a.IsVistComp == false && a.IsCancelled != true
                                                   && a.ApptDt == DateOnly.FromDateTime(DateTime.Now)).Select(a => new AppointmentDetailsDTO
            {
                AppointmentID = a.ApptId,
                PatientID = a.PatientId,
                PatientName = a.Patient.Name,
                NurseName = a.Nurse.Name,
                AptDate = a.ApptDt
            }).ToListAsync();
        }


    }
}
