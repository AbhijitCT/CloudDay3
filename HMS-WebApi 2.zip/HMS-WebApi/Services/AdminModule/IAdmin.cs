﻿using HMS_WebApi.DTO;
using HMS_WebApi.Models;

namespace HMS_WebApi.Services.AdminModule
{
    public interface IAdmin
    {
        Task<IQueryable<MasterDetails>> GetMasterDetails();
        bool CheckNursePendingAppointment(string masterid);
        bool CheckUserNameExist(string username);
        bool CheckPhysicianPendingAppointment(string masterid);
        void RemoveMasterDetails(string masterid);
        void RegisterMasterDetails(MasterDTO mas);
    }
}
