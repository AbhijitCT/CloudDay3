﻿using HMS_WebApi.DTO;
using HMS_WebApi.Models;
using Microsoft.EntityFrameworkCore;
namespace HMS_WebApi.Services.AdminModule
{
    public class AdminOperations : IAdmin
    {
        private Group1DotNetContext context;
        public AdminOperations(Group1DotNetContext context)
        {
            this.context = context;
        }

        public async Task<IQueryable<MasterDetails>> GetMasterDetails()
        {
            var users = from Master in context.Masters
                        where Master.IsActive == true && (Master.RoleId == 1 || Master.RoleId == 3)
                        select new MasterDetails
                        {
                            MasterId = Master.MstrId,
                            MasterName = Master.Name
                        };

            return users;
        }
        public bool CheckNursePendingAppointment(string masterid)
        {
            return context.Appoinments.Any(ap => ap.NurseId == masterid && ap.IsSkd == false);
        }
        public bool CheckPhysicianPendingAppointment(string masterid)
        {
            return context.Appoinments.Any(ap => ap.PhyId == masterid && ap.IsSkd == true && ap.IsVistComp == false);
        }

        public void RemoveMasterDetails(string masterid)
        {

            Master master = context.Masters.Find(masterid);
            master.IsActive = false;
            context?.SaveChanges();
            //return master;
        }

        public bool CheckUserNameExist(string username)
        {

            return context.Masters.Any(x => EF.Functions.Collate(x.Username, "SQL_Latin1_General_CP1_CS_AS") == username && x.IsActive == true);
        }
        public void RegisterMasterDetails(MasterDTO mas)
        {

            Master master = new Master();
            if (mas.RoleId == 1)
            {
                master.MstrId = "HMS-PHY" + (context?.Masters.Where(n => n.RoleId == 1).Count() + 1);
            }
            else if (mas.RoleId == 3)
            {
                master.MstrId = "HMS-NRS" + (context?.Masters.Where(n => n.RoleId == 3).Count() + 1);
            }
            master.Name = mas.Name;
            master.Username = mas.Username;
            master.Password = mas.Password;
            master.Email = mas.Email;
            master.Dob = mas.Dob;
            master.RoleId = mas.RoleId;
            master.DisezCatId = mas.DisezCatId;
            context?.Add(master);
            context?.SaveChanges();

        }
    }
}
