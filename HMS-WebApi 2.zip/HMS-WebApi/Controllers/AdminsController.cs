﻿using HMS_WebApi.Models;
using HMS_WebApi.Services.AdminModule;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using HMS_WebApi.DTO;

namespace HMS_WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminsController : Controller
    {
        private IAdmin repo;
        public AdminsController(IAdmin repo)
        {
            this.repo = repo;
        }

        [HttpGet]
        public async Task<ActionResult<IQueryable<MasterDetails>>> GetMasterDetails()
        {
            return Ok(await this.repo.GetMasterDetails());
        }

        [HttpDelete]
        [Route("RemoveMaster")]
        public IActionResult RemoveMasterDetails(string masterid)
        {
            bool flag;
            if (masterid.Contains("HMS-PHY"))
            {
                flag = this.repo.CheckPhysicianPendingAppointment(masterid);
            }
            else 
            {
                flag = this.repo.CheckNursePendingAppointment(masterid);
                Console.WriteLine(flag);
            }
            if (!flag)
            {
                this.repo.RemoveMasterDetails(masterid);
                return Ok();

            }
            else
            {
                return BadRequest();
            }
        }

        [HttpGet("CheckUserNameExist")]
        public IActionResult CheckUserNameExist(string username)
        {
            bool status = repo.CheckUserNameExist(username);
            if (status)
            {
                return Ok();
            }
            else
            {
                return NotFound();
            }

        }
        [HttpPost]
        [Route("RegisterPhysician")]
        public IActionResult RegisterPhysician(MasterDTO phy)
        {

            phy.RoleId = 1;
            this.repo.RegisterMasterDetails(phy);

            return Ok();
        }

        [HttpPost]
        [Route("RegisterNurse")]
        public IActionResult RegisterNurse(MasterDTO nurse)
        {

            nurse.RoleId = 3;

            this.repo.RegisterMasterDetails(nurse);

            return Ok();
        }

        
    }
}
