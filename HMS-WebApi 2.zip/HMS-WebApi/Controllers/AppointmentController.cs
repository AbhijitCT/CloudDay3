﻿using HMS_WebApi.DTO;
using HMS_WebApi.Models;
using HMS_WebApi.Services.AppointmentModule;
using Microsoft.AspNetCore.Mvc;

namespace HMS_WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AppointmentController : Controller
    {
        IAppointment aptman;
        public AppointmentController(IAppointment Appt)
        {
            this.aptman = Appt; 
        }

        [HttpGet]
        [Route("GetPhysicianForDscCtg/{DscCtgId}")]
        public async Task<ActionResult<IEnumerable<MasterDetails>>> PhysicianForDscCtg(string DscCtgId)
        {
            return Ok(await this.aptman.GetPhysicianForDscCtg(DscCtgId));
        }
        [HttpGet]
        [Route("GetNursesForDscCtg/{DszCtgId}")]
        public async Task<ActionResult<IEnumerable<MasterDetails>>> NursesForDscCtg(string DszCtgId)
        {
            return Ok(await this.aptman.GetNursesForDscCtg(DszCtgId));
        }
        [HttpGet]
        [Route("GetAllScheduledAppointmentHistoryForNurse/{NurseID}")]
        public async Task<ActionResult<IEnumerable<AppointmentDetailsDTO>>> GetAllScheduledAppointmentHistoryForNurse(string NurseID)
        {
            Console.WriteLine(NurseID);
            return Ok(await this.aptman.GetAllScheduledAppointmentHistoryForNurse(NurseID));
        }



        [HttpPost]
        public async Task<ActionResult> Appointment(BookAptDTO apt)
        {
            aptman.BookAppointment(apt);
            return Ok();
        }

        [HttpPut]
        public async Task<ActionResult> UpdateAppointment(ScheduleAptDTO apt)
        {
            Console.WriteLine(apt.ApptId);
            Console.WriteLine(apt.PhyId);
            aptman.ScehduleAppointment(apt);
            return Ok();
        }

        [HttpDelete("{AptID}")]
        public async Task<ActionResult> CancelAppointment(string AptID)
        {
            Console.WriteLine("Hello World");
            aptman.CancelAppoitnment(AptID);
            return Ok();
        }

    }
}