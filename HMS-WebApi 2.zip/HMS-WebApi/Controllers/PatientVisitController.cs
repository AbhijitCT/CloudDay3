﻿using HMS_WebApi.DTO;
using HMS_WebApi.Models;
using HMS_WebApi.Services.PatientVisitModule;
using Microsoft.AspNetCore.Mvc;

namespace HMS_WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PatientVisitController : ControllerBase
    {
        private readonly IPatientVisit _patientVisitService;

        public PatientVisitController(IPatientVisit patientVisitService)
        {
            _patientVisitService = patientVisitService;

        }

        [HttpPost]
        public ActionResult<string> CreatePatientVisit(PatientVisitDTO patientVisit)
        {
            Console.WriteLine(patientVisit.BpId+" ");
            _patientVisitService.CreatePatientVisit(patientVisit);
            return Ok();
        }
            
        //[HttpGet]
        //[Route("GetAppointmentIDsForPhy/{PhyId}")]
        //public async Task<ActionResult<List<string>>> GetAppointmentIDsForPhy(string PhyId)
        //{
        //    return Ok(await this._patientVisitService.GetAptIDsForPhy(PhyId));
        //}
         [HttpGet]
        [Route("GetAppointmentIDsForPhy/{PhyId}")]
        public async Task<ActionResult<List<string>>> GetAppointmentIDsForPhy(string PhyId)
        {
            return Ok(await this._patientVisitService.GetAptIDsForPhy(PhyId));
        }

        [HttpGet]
        [Route("GetBloodPressureTyp")]
        public async Task<ActionResult<List<BloodPressureDTO>>> GetBloodPressureTyp()
        {
            return Ok(await this._patientVisitService.GetBloodPressureType());
        }
        [HttpGet]
        [Route("GetDiagnosisForDsz/{DscCtgId}")]
        public async Task<ActionResult<List<DiagonsisDTO>>> GetDiagnosisForDsz(string DscCtgId)
        {
            return Ok(await this._patientVisitService.GetDigForDszCtg(DscCtgId));
        }
        [HttpGet]
        [Route("GetMedicineForDigCtg/{DigCtgId}")]
        public async Task<ActionResult<List<BloodPressureDTO>>> GetMedicineForDigCtg(string DigCtgId)
        {
            return Ok(await this._patientVisitService.GetMedForDigCtg(DigCtgId));
        }
        [HttpGet]
        [Route("GetAllergyTypForDigCtg/{DscCtgId}")]
        public async Task<ActionResult<List<AllergyDTO>>> GetAllergyTypForDigCtg(string DscCtgId)
        {
            var result = await this._patientVisitService.GetAlgTypForDigCtg(DscCtgId);
            foreach (var a in result)
            {
                Console.WriteLine(a.AllergyId + " " + a.AllergyNm);
            }
            return Ok(result);
        }


        [HttpGet("PatientVistsForPhy/{PhyId}")]

        public async Task<ActionResult<List<AppointmentDetailsDTO>>> GetPatientVisitsForPhy(string PhyId)
        {
            var result = await _patientVisitService.PatientVisitsForPhy(PhyId);
            Console.WriteLine("Hello");
            foreach(var a in result)
            {
                Console.WriteLine(a.NurseName);
            }
            Console.WriteLine("World");
            return Ok(result);
  
        }

        [HttpGet("PatientVistDetails/{VisitID}")]

        public async Task<ActionResult<List<PatientVisitDetailsDTO>>> GetPatientVisitDetails(string VisitID)
        {
            var result = await _patientVisitService.PatientVisitDetails(VisitID);
            Console.WriteLine("Hello");
            Console.WriteLine(result);
            Console.WriteLine("World");
            return Ok(result);

        }
    }
}
