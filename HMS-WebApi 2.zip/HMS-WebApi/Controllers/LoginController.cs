﻿using HMS_WebApi.Models;
using HMS_WebApi.Services.LoginModule;
using Microsoft.AspNetCore.Mvc;
using HMS_WebApi.DTO;
namespace HMS_WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly ILogin _loginService;

        public LoginController(ILogin loginService)
        {
            _loginService = loginService;
        }

        [HttpGet("CheckUserNameExist")]
        public IActionResult CheckUserNameExist(string username)
        {
            bool status = _loginService.CheckUserNameExist(username);
            if (status)
            {
                return Ok();
            }
            else
            {
                return NotFound();
            }

        }
        [HttpGet("CheckUserPassword")]
        public IActionResult CheckUserPassword(string username, string password)
        {
            bool status = _loginService.CheckUserPassword(username, password);
            if (status)
            {
                return Ok();
            }
            else
            {
                return NotFound();
            }
        }

        [HttpGet("BlockUser")]
        public IActionResult BlockUser(string username)
        {
            bool status = _loginService.BlockUser(username);
            if (status)
            {
                return Ok();
            }
            else
            {
                return NotFound();
            }
        }

        [HttpGet("CheckUserInBlockLst")]
        public IActionResult CheckUserInBlockLst(string username)
        {
            bool status = _loginService.CheckUserInBlockLst(username);
            if (status)
            {
                return Ok();
            }
            else
            {
                return NotFound();
            }
        }

        [HttpGet("GetMaster")]
        public ActionResult GetMaster(string username, string password)
        {
            Master? master = _loginService.GetMaster(username, password);
            if (master != null)
            {
                return Ok(master);
            }
            else
            {
                return NotFound();
            }
        }

        [HttpGet("ForgetPasswordDetails")]
        public IActionResult ForgetPasswordDetails(string username)
        {
            string name = "", password = "";
            _loginService.ForgetPasswordDetails(username, out name, out password);
            return Ok(new { Name = name, Password = password });
        }

        [HttpPost("UpdatePassword")]
        public IActionResult UpdatePassword(ChangePasswordDTO usrdet)
        {
            try
            {
                bool success = _loginService.UpdatePassword(usrdet.Username, usrdet.NewPassword);
                if (success)
                    return Ok("Password updated successfully.");
                else
                    return BadRequest("Failed to update password.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred: {ex.Message}");
            }
        }


        [HttpPost]
        public string GetPassword()
        {
            return "Password returned successsfulyy";
        }
    }
}
