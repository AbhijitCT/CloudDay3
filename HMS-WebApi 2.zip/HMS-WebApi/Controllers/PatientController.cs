﻿using HMS_WebApi.Services.PatientModule;
using HMS_WebApi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using HMS_WebApi.DTO;
using Microsoft.Identity.Client;

namespace HMS_WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PatientController : ControllerBase
    {
        IPatient patientSrv;
        public PatientController(IPatient pat)
        {
            this.patientSrv = pat;
        }
        [HttpGet]
        [Route("GetDiseases")]
        public async Task<ActionResult<IEnumerable<DiseaseCategory>>> GetDiseases()
        {
            return Ok(await this.patientSrv.GetDisease());
        }

        [HttpGet]
        [Route("{PatID}/PersonalDetails")]
        public async Task<ActionResult> GetPersonalDetails(string PatID)
        {
            var result = await patientSrv.ViewPersonalDetails(PatID);
            if(result == null)
            {
                return NotFound();
            }
            return Ok(result);
        }

        [HttpGet]
        [Route("{PatID}/DownloadDetails")]
        public async Task<ActionResult> DownloadPersonalDetails(string PatID)
        {
            var result = await patientSrv.DownloadPersonalDetails(PatID);
            if(result.Item1 == null || result.Item2 == null)
            {
                return NotFound();
            }
            return File(result.Item1,"text/csv", result.Item2);
            //var filepath = await patientSrv.DownloadPersonalDetails(PatID);
            //if (filepath == null)
            //    return NotFound();

            //return File(System.IO.File.OpenRead(filepath),"text/csv",$"{filepath}");
            
        }

        [HttpGet]
        [Route("{patID}/VisitHistory")]
        public async Task<ActionResult> VisitHistory(string patID)
        {
            return Ok(await patientSrv.ViewVisitHistory(patID));
        }


        //[HttpGet]
        //public async Task<ActionResult> GetDiseases()
        //{
        //    var diseases = await patientSrv.GetDisease();
        //    return Ok(diseases);
        //}

        [HttpGet("CheckUserNameExist")]
        public IActionResult CheckUserNameExist(string username)
        {
            bool status = patientSrv.CheckUserNameExist(username);
            if (status)
            {
                return Ok();
            }
            else
            {
                return NotFound();
            }

        }

        [HttpPost]
        [Route("RegisterPatient")]
        public IActionResult RegisterPatient(MasterDTO patient)
        {

            patient.RoleId = 2;
            this.patientSrv.RegisterPatient(patient);

            return Ok();
        }
    }
}
