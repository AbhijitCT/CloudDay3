﻿using HMS_WebApi.DTO;
using HMS_WebApi.Models;
using HMS_WebApi.Services.InboxModule;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HMS_WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InboxController : ControllerBase
    {
        IInbox inbox;
        public InboxController(IInbox inbx)
        {
            inbox = inbx;
        }

        [HttpGet]
        [Route("NurseInbox/{NurseId}")]
        public async Task<ActionResult<IEnumerable<AppointmentDetailsDTO>>> AppointmentToBeScheduleForNurse(string NurseId)
        {
            return Ok(await inbox.GetAppointmentToBeScheduledList(NurseId));
        }

        [HttpGet]
        [Route("PhyUpcomingApts/{PhyId}")]
        public async Task<ActionResult<IEnumerable<AppointmentDetailsDTO>>> UpcomingAppointmentScheduledForPhy(string PhyId)
        {
            return Ok(await inbox.UpcomingGetScheduledAppointmentList(PhyId));
        }
        [HttpGet]
        [Route("PhyTodaysApt/{PhyId}")]
        public async Task<ActionResult<IEnumerable<AppointmentDetailsDTO>>> AppointmentScheduledForPhyToday(string PhyId)
        {
            return Ok(await inbox.GetScheduledAppointmentListForToday(PhyId));
        }
    }
}
